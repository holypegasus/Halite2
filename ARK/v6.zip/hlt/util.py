import logging, math
from collections import Counter, OrderedDict, defaultdict
from functools import partial, wraps
from operator import truediv
from time import time


def timit(f):
  @wraps(f)
  def wrap(*args, **kwargs):
    t0 = time()
    result = f(*args, **kwargs)
    t1 = time()
    logging.warning('%s took: %.0f ms', f.__name__, (t1-t0)*1000)
    return result
  return wrap


def timit_name(text):
  if text:  print(text)
  return timit


def setup_logger(name, file_name=None, level=logging.INFO):
  log = logging.getLogger(name)
  log.setLevel(level)
  # fh = logging.FileHandler('%s.log'%(file_name), mode='w')
  # fh.setFormatter(
  #   logging.Formatter('%(asctime)s <%(module)s.%(funcName)s:%(lineno)d> %(message)s', '%Y%m%d %H:%M:%S'))
  # log.addHandler(fh)
  sh = logging.StreamHandler()
  sh.setFormatter(
    logging.Formatter('%(asctime)s <%(module)s.%(funcName)s:%(lineno)d> %(message)s', '%Y%m%d %H:%M:%S'))
  log.addHandler(sh)
  return log


def logitr(itr, header=''):
  if itr and header:  logging.debug('%s: [%s]', header, len(itr))
  if issubclass(type(itr), dict):
    for k, v in sorted(itr.items()):
      logging.debug('%s -> %s', k, v)
  else:
    for v in itr: logging.debug(v)


if __name__ == '__main__':
  logging.basicConfig(level=logging.INFO, format='<%(module)s.%(funcName)s:%(lineno)d> %(message)s')

  test='timit'

  if test=='timit':
    @timit
    def timed(t=1e4):
      assert t<=1e8
      t=int(t)
      for _ in range(t):  _
      logging.info('Running timed() {:,} times...'.format(t))

    timed(1e7)
  elif test=='log':
    # setup_logger
    log = setup_logger(__name__, level=logging.INFO)
    log.info('something')
    # logitr
    d = {str(i): i for i in range(5)}
    logitr(d, 'test_header')