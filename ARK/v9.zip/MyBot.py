"""
Welcome to your first Halite-II bot!

This bot's name is Settler. It's purpose is simple (don't expect it to win complex games :) ):
1. Initialize game
2. If a ship is not docked and there are unowned planets
2.a. Try to Dock in the planet if close enough
2.b If not, go towards the planet

Note: Please do not place print statements here as they are used to communicate with the Halite engine. If you need
to log anything use the logging module.
"""
# Let's start by importing the Halite Starter Kit so we can interface with the Halite engine
import logging
import numpy as np
from collections import Counter, OrderedDict, defaultdict, namedtuple
from itertools import chain
from time import time

import hlt
from hlt import Game, constants
from hlt.entity import Entity, Planet, Ship, Position, Vector
from hlt.util import setup_logger, logitr, timit


BOT_NAME = 'v9_WIP'
# Game params
LOG_LEVEL = logging.DEBUG
LOG_LEVEL = logging.INFO
LOG_LEVEL = logging.WARNING
LOG_LEVEL = logging.CRITICAL
LIMIT_TURNS = float('inf')
# LIMIT_TURNS = 40
PLOT_TURNS = set()
# PLOT_TURNS = set(range(35, LIMIT_TURNS))

# Logic params
ANGULAR_STEP = 10
MAX_CORRECTIONS = 10
PC = 2  # coordinate-precision
TIMEOUT_BREAKER = 1.800


def log(*args, lvl=logging.DEBUG):
  logger = {
    logging.DEBUG: logging.debug,
    logging.INFO: logging.info,
    logging.WARNING: logging.warning,
    logging.CRITICAL: logging.critical,
  }.get(lvl)
  logger(*args)


# find threats within origin's safety-perimeter
# return unclaimed nearest threat to ship
# TODO generalize perimeter -> area_threat_vector
# TODO project foe_ships curr_pos ->  w/ guess_next_pos
# TODO memoize by using generator for each particular planet
# @timit
def scan_perimeter(ship, origin):
  assert isinstance(origin, Planet)
  # dist8nearest_foe_ship = min([(origin.dist(s), s) for s in r.foe_ships], key=lambda ds: ds[0])
  r = game_map.rec

  turns_to_safe = constants.DOCK_TURNS
  # all foe_ships w/ guess_next_pos within perimeter of origin
  # TODO generalize to all foe_ship w/ threat_vector into perimeter
  # ? foe_ships vs foe_mobos
  foe8next_pos = [(f, f.guess_next_pos()) for f in r.foe_ships]
  in_perim_foe8next_pos = set()
  for foe, next_pos in foe8next_pos:
    # TODO get actual dist to proposed docking spot
    dist_to = origin.dist(foe)
    turns_from_foe = dist_to / constants.MAX_SPEED
    if turns_from_foe <= turns_to_safe:
      in_perim_foe8next_pos.add((foe, next_pos))

  sorted_ship_dist_to8foe = sorted([(ship.dist(np), f) for (f, np) in in_perim_foe8next_pos], key=lambda d8f: d8f[0])
  logitr(sorted_ship_dist_to8foe, 'ship_dist_to8foe', 20)
  for ship_dist_to, foe in sorted_ship_dist_to8foe:
    # if ship already targetting foe || not targetted yet
    if ship.goal==foe or not foe.goals_of:
      logging.info('Perimeter_foe! %s @ %.1f from %s', foe, ship_dist_to, ship)
      return ship_dist_to, foe

  return None, None


# update memo when ship stays
def record_stay(ship):
  game_map.add_obst(ship)
  game_map.add_dest(ship)

def record_move(ship, target):
  game_map.add_dest(target)
  navi_path = Vector(ship, target, r=ship.radius, pc=PC)
  # sprinkle navigational dust into RESERVED_LOCS
  # TODO improve perf by geometric-check of path-crossing
  navi_dots = list(navi_path.gen_pts(int(constants.MAX_SPEED/ship.radius*2)))
  [game_map.obsts.add(navi_dot) for navi_dot in navi_dots]
  game_map.add_path(navi_path)



# @timit
def get_act(ship, goal):
  assert isinstance(goal, Planet) or isinstance(goal, Ship)
  logging.info('%s --d:%s--> %s', ship, ship.dist(goal), goal)
  r = game_map.rec
  navigate_command = None
  if isinstance(goal, Planet) and ship.can_dock(goal):
    logging.info('DOCK! %s, %.2f away from %s', ship, ship.dist(goal)-goal.radius, goal)
    navigate_command = ship.dock(goal)
    record_stay(ship)
  else:
    # TODO make sure rounding min_dist correctly for various scenarios
    if isinstance(goal, Planet):
      min_dist = .5 # hug planet!  #constants.DOCK_RADIUS - .5
    elif isinstance(goal, Ship):
      # TEST goal -> goal's predicted next pos
      goal = goal.guess_next_pos()
      MIN_MOVE_THRUST = 1
      desired_min_dist = constants.WEAPON_RADIUS  # TEST if further better
      dist_to_goal = ship.dist(goal)
      if dist_to_goal <= desired_min_dist:
        record_stay(ship)
        return
      else:
        # NB when just beyond, make sure THRUST at least 1
        # eg @5.28 away trying to keep 4 min_dist from a radius 0.5 ship
        # 0.78 thrust rounds to 0 !!!
        # want: 1 <= THRUST = dist_to_goal - (desired_min_dist + goal.radius)
        # thus: min_dist = dist_to_goal - goal.radius - 1 in edge case
        lower_bound_min_dist = max(0, dist_to_goal - goal.radius - MIN_MOVE_THRUST)
        min_dist = min(desired_min_dist, lower_bound_min_dist)
    target = ship.perigee(goal, min_dist=min_dist)  # -> target-perigee
    logging.debug("goal's target-perigee: -> %s", target)
    navigate_command, eff_target = ship.navigate_smart(
      target=target,
      game_map=game_map,
      angular_step=ANGULAR_STEP,
      max_corrections=MAX_CORRECTIONS,
    )
    if navigate_command:  # move
      # logging.warning('Goal acquired %s', goal)
      # logging.warning('Moving %s -> %s', ship, eff_target)
      record_move(ship, eff_target)
    else:  # no move
      game_map.obsts.add(ship)
      # check if anything dockable :D
      for p in (r.free_planets | r.open_planets):
        if ship.can_dock(p):
          logging.warning('Nothing to do but planet dockable next door...DOCK! %s -> %s', ship, p)
          # goal changed? need to update_ship8goal_memos
          game_map.update_ship8goal_memos(ship, p)
          navigate_command = ship.dock(p)
          record_stay(ship)

  return navigate_command


def eff_dist(e0, e1):
  dist = e0.dist(e1)
  # if isinstance(e1, Planet):
  #   dist = dist - e1.radius - constants.DOCK_RADIUS
  # elif isinstance(e1, Ship):
  #   dist = dist - constants.WEAPON_RADIUS
  # dist = max(0, dist)
  return dist


def prep_goals(ship, goals):
  eff_dist8ship8goal = [(eff_dist(ship, goal), ship, goal) for goal in goals]
  return eff_dist8ship8goal
  # return sorted(eff_dist8ship8goal, key=lambda d8g: d8s8g[0])


def prep_all_ship_goals():
  r = game_map.rec
  goals = r.free_planets | r.open_planets | r.foe_imobos | r.foe_mobos
  all_eff_dist8ship8goal = [prep_goals(s, goals) for s in r.my_mobos]  # list of lists
  all_eff_dist8ship8goal = list(chain(*all_eff_dist8ship8goal))  # flatten into 1 list
  # logging.critical(all_eff_dist8ship8goal)
  return all_eff_dist8ship8goal


@timit
def global_eval_goals():
  assigned_ships = set()
  dist8ship8goal = []
  i = 0
  sorted_all_dsg = sorted(prep_all_ship_goals(), key=lambda dsg: dsg[0])
  for d, s, g in sorted_all_dsg:
    if s in assigned_ships:
      continue
    if isinstance(g, Planet):
      committed_ships = g.goals_of
      n_open_docks = g.num_docking_spots - len(committed_ships)
      if n_open_docks <= 0 and s not in committed_ships:
        continue

    i += 1

    if isinstance(g, Planet):
      ship_dist_to, perimeter_threat = scan_perimeter(s, g)
      if perimeter_threat:
        g = perimeter_threat
        d = eff_dist(s, perimeter_threat)

    dist8ship8goal.append((d, s, g))
    assigned_ships.add(s)
    game_map.update_ship8goal_memos(s, g)

  logging.warning('Deep-evaled: %s', i)
  logitr(dist8ship8goal, 'dist8ship8goal', 30)
  return dist8ship8goal


# to start just direct each ship to its optimal goal
# TODO spatial-search goal only within reachable 
@timit
def eval_goals():
  r = game_map.rec
  """ TODO
    order ship intelligently (spatial - border first?)
    eval effective-dist (ED)
    update ED after each action?
  """
  goals = r.free_planets | r.open_planets | r.foe_imobos | r.foe_mobos
  ship2dist8goal = dict()
  i = 0
  for ship in r.my_mobos:
    # pick goal
    # TODO pick goal smarter
    for goal in goals:
      # check if Planet
      # 1) saturated docking spot (including enroute ships)
      # 2) already assigned for docking for this Ship
      # TODO nuant w/ area-threat-vector-analysis
      if isinstance(goal, Planet):
        committed_ships = goal.goals_of
        open_docks = goal.num_docking_spots - len(committed_ships)
        if open_docks <= 0 and ship not in committed_ships:
          # logging.warning('Skipping %s because open_docks: %s; committed_ships: %s', goal, )
          continue

      i+=1
      ### TODO eval target + effective dist
      dist = eff_dist(ship, goal)
      if ship not in ship2dist8goal or dist < ship2dist8goal[ship][0]:
        ship2dist8goal[ship] = dist, goal
        # ship2dist8goal[s].append((d, g))  # carry list of possible goals
    # double-check goal after first-pass through all-goals
    dist, goal = ship2dist8goal[ship]  # best (dist, goal) for ship
    logging.debug('%s ..> %s', ship, goal)
    if isinstance(goal, Planet):
      # NB redirect to unmatched foe nearest ship if original goal scan_perimeter reveals threat
      ship_dist_to, perimeter_threat = scan_perimeter(ship, goal)
      if perimeter_threat:
        goal = perimeter_threat
        dist = eff_dist(ship, perimeter_threat)
        ship2dist8goal[ship] = dist, goal
    game_map.update_ship8goal_memos(ship, goal)


  sorted_dist8ship8goal = sorted(((d8g[0], s, d8g[1]) for s, d8g in ship2dist8goal.items()), key=lambda dsg: dsg[0])

  logging.critical('Deep-evaled: %s', i)
  logitr(sorted_dist8ship8goal, 'sorted_dist8ship8goal', 50)

  return sorted_dist8ship8goal


@timit
def turn():
  # Update the map for the new turn and get the latest version
  game.update_map()
  # start timer
  t0 = time()
  # from curr_turn game_map recalc various records & update memos
  game_map.turn_update_memos()
  # TURN START
  command_queue = []
  # TODO iterate-merge eval_goal & get_act
  # eval a goal per ship & update ship & goal memos
  # sorted_dist8ship8goal = eval_goals()
  sorted_dist8ship8goal = global_eval_goals()
  # foreach goal
  for i, (dist, ship, goal) in enumerate(sorted_dist8ship8goal):
    td = time() - t0
    if td >= TIMEOUT_BREAKER:
      log('TIMEOUT_BREAKER! ship #%d; time-elapsed: %.4f', i, td, lvl=50)
      break
    navigate_command = get_act(ship, goal)
    if navigate_command:
      command_queue.append(navigate_command)

  # OPT show memos end-of-turn
  game_map.show_goals(level=30)
  game_map.show_goals_of(level=30)
  # Send our set of commands to the Halite engine for this turn
  # logitr([c.split()[1:] for c in command_queue], 'command_queue', level=30)
  game.send_command_queue(command_queue)
  # TURN END



# GAME START
game = Game(name=BOT_NAME, log_level=LOG_LEVEL)
gm = game_map = game.map
# TODO 60secs of preprocess window here!



# Main
while True:
  if game.curr_turn > LIMIT_TURNS:  break  # short-horizon tests
  # INTRA-turn memos -> should all go into game_map
  turn()
  # opt plot - plot only turns with movement
  if game.curr_turn in PLOT_TURNS and game_map.paths:
    from hlt.plot import Pltr
    pltr = Pltr(game_map.width, game_map.height)

    r = game_map.rec
    # logitr(r.free_planets, 'free_planets', 30)
    pltr.plt_circles(r.free_planets, c='gray', fill=False)
    # FOES
    pltr.plt_circles(r.foe_imobos, c='purple')
    pltr.plt_circles(r.foe_planets, c='purple')
    pltr.plt_circles(r.foe_mobos, c='red')
    guess_foe_next_pos = [s.guess_next_pos() for s in r.foe_mobos]
    guess_foe_paths = [Vector(s, s.guess_next_pos()) for s in r.foe_mobos]
    logitr(guess_foe_paths, 'guess_foe_next_pos', 30)
    pltr.plt_lines(guess_foe_paths, linestyle=':', c='red')
    pltr.plt_circles(guess_foe_next_pos, r=constants.WEAPON_RADIUS, c='red', fill=False)
    # MINE
    pltr.plt_circles(r.my_imobos, c='green')
    pltr.plt_circles(r.my_planets, c='green')
    pltr.plt_circles(r.my_mobos, c='blue')
    to_goals = [Vector(s, s.goal) for s in r.my_mobos]
    pltr.plt_lines(to_goals, linestyle=':', c='blue')
    pltr.plt_lines(game_map.paths, c='blue')
    pltr.plt_circles(game_map.dests, r=constants.WEAPON_RADIUS, c='blue', fill=False)
    # pltr.plt_circles(game_map.dests, r=constants.DOCK_RADIUS, c='blue', fill=False)

    # grid = Grid(game_map, precision=0)
    # grid.map_entities(game_map.all_planets())
    # pltr.plt_matrix(grid)

    # pltr.show()
    pltr.savefig(turn=game.curr_turn)
# GAME END
