"""
Welcome to your first Halite-II bot!

This bot's name is Settler. It's purpose is simple (don't expect it to win complex games :) ):
1. Initialize game
2. If a ship is not docked and there are unowned planets
2.a. Try to Dock in the planet if close enough
2.b If not, go towards the planet

Note: Please do not place print statements here as they are used to communicate with the Halite engine. If you need
to log anything use the logging module.
"""
# Let's start by importing the Halite Starter Kit so we can interface with the Halite engine
import logging
from collections import OrderedDict, defaultdict
from time import time

import hlt
from hlt import Game, constants
from hlt.entity import Entity, Planet, Ship, Position
from hlt.util import setup_logger, logitr, timit
from hlt.geo import Line


BOT_NAME = 'v6_unify_targets_reduce_collision'
# Game params
LOG_LEVEL = logging.WARNING
# LOG_LEVEL = logging.INFO
# LOG_LEVEL = logging.DEBUG
LIMIT_TURNS = float('inf')
# LIMIT_TURNS = 6
PLOT_FROM, PLOT_UNTIL = float('inf'), -1
# PLOT_FROM, PLOT_UNTIL = 0, LIMIT_TURNS

# Logic params
ANGULAR_STEP = 10
MAX_CORRECTIONS = 10
PC = 2  # coordinate-precision


# @timit
def get_action(ship, target, RESERVED_LOCS, PATH_RECS):
  logging.debug('NAVI: {} ..{:.2f}..> {}'.format(ship, ship.dist(target), target))
  navigate_command = None
  # TODO coordinate docking to avoid waste
  if isinstance(target, Planet) and ship.can_dock(target):
    logging.debug('DOCK! @ dist={:.2f}'.format(ship.dist(target) - target.radius))
    RESERVED_LOCS.add(Position(round(ship.x, PC), round(ship.y, PC), round(ship.radius, PC)))
    navigate_command = ship.dock(target)
  else:
    if isinstance(target, Planet):
      min_dist = 1.  # TODO longer to reach vs reduce crowding?
    elif isinstance(target, Ship):
      min_dist = constants.WEAPON_RADIUS - 1.  # TODO fudge necessary?
    target = ship.peri(target, min_dist=min_dist)  # -> target-perigee
    logging.debug('target-peri: -> %s', target)
    navigate_command, eff_target = ship.navigate_smart(
      Position__target=target,
      game_map=game_map,
      speed=constants.MAX_SPEED,
      angular_step=ANGULAR_STEP,
      max_corrections=MAX_CORRECTIONS,
      set__reserved_locs=RESERVED_LOCS,
    )
    if navigate_command:
      # logging.debug('THRUST %s', navigate_command)
      # plot targets
      RESERVED_LOCS.add(Position(round(target.x, PC), round(target.y, PC), round(target.radius, PC)))
      PATH_RECS.append(Line(ship, eff_target))
      # memoize targets
      if isinstance(target, Planet):
        pass
      elif isinstance(target, Ship):
        pass
        # ship.target_status = target.docking_status
      elif isinstance(target, Position):
        pass
      # SID2TGT[ship.id] = Position(target.x, target.y)
      # logging.debug('%s memoized target: %s', ship, target)
    else:
      # logging.debug('##### NO navigate_command - max_corrections exceeded! #####')
      pass
  return navigate_command


# to start just direct each ship to its optimal target
# TODO spatial-search target only within reachable 
# NB don't need to over-optimze - takes very little time
# @timit
def eval_targets(ships, targets):
  logging.debug('%s ships; %s targets', len(ships), len(targets))
  t0=time()
  # TODO use auto-resort data-struct vs sort-at-end?
  ship2dist8target = defaultdict(list)
  for i, s in enumerate(ships):
    for t in targets:
      d = s.dist(t)
      # TODO iter eval-func
      # TMP stab at smarting...prioritize planets then foe_imobo
      # d /= 7  # d -> n_turns
      if isinstance(t, Planet):
        d /= BUILD_Q
      elif t.docking_status!=t.DockingStatus.UNDOCKED:
        d /= FIGHT_Q
      #
      if s not in ship2dist8target or d < ship2dist8target[s][0]:
        ship2dist8target[s] = (d, t)
      # ship2dist8target[s].append((d, t))
    # ship2dist8target[s].sort(key=lambda d8t: d8t[0])
    # TMP limit target-list to save computation
    # SHIP_TARGET_LIMIT = 5
    # ship2dist8target[s] = ship2dist8target[s][:SHIP_TARGET_LIMIT]
    # logitr(ship2dist8target[s], "# %s: %s's dist & target"%(i, s))
  # sorted_dist8ship8target = sorted((d8ts[0][0], s, d8ts[0][1]) for s, d8ts in ship2dist8target.items())

  sorted_dist8ship8target = sorted(((d8t[0], s, d8t[1]) for s, d8t in ship2dist8target.items()), key=lambda dst: dst[0])
  # TODO output global [(best_dist, one_ship_s_dist8target)]
  logitr(sorted_dist8ship8target, 'sorted_dist8ship8target')
  return sorted_dist8ship8target


# @timit
def turn(game):
  # Update the map for the new turn and get the latest version
  game.update_map()
  # TURN START
  # COMMAND START
  command_queue = []
  # Get ships
  t0=time()
  all_ships = set(game_map._all_ships())
  sid2ship = {s.id: s for s in all_ships}
  my_ships = set(game_map.get_me().all_ships())
  my_mobo_ships = set(s for s in my_ships if s.docking_status==s.DockingStatus.UNDOCKED)
  my_imobo_ships = my_ships - my_mobo_ships
  logging.debug('My Ships: %s/%s UNDOCKED', len(my_mobo_ships), len(my_ships))
  foe_ships = all_ships - my_ships
  foe_mobo_ships = set(s for s in foe_ships if s.docking_status==Ship.DockingStatus.UNDOCKED)
  foe_imobo_ships = foe_ships - foe_mobo_ships
  # Global entity status
  my_docking_planets = set(s.planet for s in my_imobo_ships)
  foe_docking_planets = set(s.planet for s in foe_imobo_ships)
  # logitr(foe_docking_planets, 'foe_docking_planets')
  # Get planetary stats
  all_planets = set(game_map.all_planets())
  my_planets = set(p for p in all_planets if p.is_owned() and p.owner.id==MY_ID)
  foe_planets = set(p for p in all_planets if p.is_owned() and p.owner.id!=MY_ID)
  free_planets = all_planets - my_planets - foe_planets - foe_docking_planets
  open_planets = set(p for p in my_planets if not p.is_full())
  logging.debug('Planets: %s/%s free; %s/%s open',
    len(free_planets), len(all_planets), len(open_planets), len(my_planets))
  """
  TODO
    order ship intelligently (spatial - border first?)
    eval effective-dist (ED)
    update ED after each action?

  """
  targets = free_planets | open_planets | foe_imobo_ships | foe_mobo_ships
  sorted_dist8ship8target = eval_targets(my_mobo_ships, targets)
  logitr(sorted_dist8ship8target, 'sorted_dist8ship8target')
  # sorted_dist8my_mobo_ships = sorted([(s.dist(SID2TGT[s.id]) if SID2TGT.get(s.id) else float('inf'), s) for s in my_mobo_ships], key=lambda t: t[0])
  # logitr(sorted_dist8my_mobo_ships, 'sorted_dist8my_mobo_ships')
  for i, (dist, ship, target) in enumerate(sorted_dist8ship8target):
    # logging.debug('target? %s --%s--> %s', ship, dist, SID2TGT.get(ship.id))
    logging.debug('t%sc%ss%s!', game.curr_turn-1, i, ship.id)
    # if isinstance(t, Planet) and len(t.Ships__to_dock)>=t.num_docking_spots:
    #   continue
    navigate_command = get_action(ship, target, RESERVED_LOCS, PATH_RECS)
    if navigate_command:
      command_queue.append(navigate_command)
    else:
      logging.debug('%s WAITS...', ship)

  # Send our set of commands to the Halite engine for this turn
  game.send_command_queue(command_queue)
  # TURN END



# GAME START
game = Game(name=BOT_NAME, log_level=LOG_LEVEL)
game_map = game.map
# TODO adapt strategy by layout/density/dist etc.
n_players = len(game_map._players)
if n_players==2:
  BUILD_Q = 2
  FIGHT_Q = 4
else:  # 4-players
  BUILD_Q = 4
  FIGHT_Q = 2

MY_ID = game_map.my_id
# TODO memoize common info across turns
SID2TGT = dict()  # ship.id -> target.(type, (x, y)) TODO generalize to moving ships
while True:
  if game.curr_turn > LIMIT_TURNS:  break  # short-horizon tests
  # in-turn memos
  RESERVED_LOCS = set()
  PATH_RECS = []
  turn(game)
  # opt plot
  # if PLOT_FROM <= game.curr_turn <= PLOT_UNTIL and PATH_RECS:
  #   pltr = Pltr(game_map.width, game_map.height)
  #   pltr.plt_circles(game_map.all_planets())
  #   pltr.plt_lines(PATH_RECS)
  #   pltr.savefig(turn=game.curr_turn)
# GAME END

