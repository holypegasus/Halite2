import logging

from . import constants
from .entity import Position, Entity
from .util import rnd



def segment_nearest_point_to(start, end, entity):
  pass



def intersect_segment_circle(start, end, circle, fudge=constants.SHIP_RADIUS):
  """
  Test whether a line segment and circle intersect.

  :param Entity start: The start of the line segment. (Needs x, y attributes)
  :param Entity end: The end of the line segment. (Needs x, y attributes)
  :param Entity circle: The circle to test against. (Needs x, y, r attributes)
  :param float fudge: A fudge factor; additional distance to leave between the segment and circle. (Probably set this to the ship radius, 0.5.)
  :return: True if intersects, False otherwise
  :rtype: bool
  """
  # Derived with SymPy
  # Parameterize the segment as start + t * (end - start),
  # and substitute into the equation of a circle
  # Solve for t
  dx = end.x - start.x
  dy = end.y - start.y

  a = dx**2 + dy**2
  b = -2 * (start.x**2 - start.x*end.x - start.x*circle.x + end.x*circle.x +
        start.y**2 - start.y*end.y - start.y*circle.y + end.y*circle.y)
  c = (start.x - circle.x)**2 + (start.y - circle.y)**2

  if a == 0.0:
    # Start and end are the same point
    return start.calculate_distance_between(circle) <= circle.radius + fudge

  # Time along segment when closest to the circle (vertex of the quadratic)
  t = min(-b / (2 * a), 1.0)
  if t < 0:
    return False

  closest_x = start.x + dx * t
  closest_y = start.y + dy * t
  segment_closest_pt_to_circle = Position(closest_x, closest_y)
  closest_distance = segment_closest_pt_to_circle.calculate_distance_between(circle)
  # round-down to be conservative about collision
  rounded_down_closest_distance = rnd(closest_distance, constants.PRECISION, '-')
  # if intersect
  if rounded_down_closest_distance <= circle.radius + fudge:
    logging.debug('INTERSECT! %s closest-pt %s d=%.2f <= %.2f to %s', start, segment_closest_pt_to_circle, rounded_down_closest_distance, circle.radius+fudge, circle)
    return True
  else:
    logging.debug('NO TOUCH! %s closest-pt %s d=%.2f > %.2f to %s', start, segment_closest_pt_to_circle, rounded_down_closest_distance, circle.radius+fudge, circle)
    return False

