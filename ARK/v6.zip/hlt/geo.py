


class Loc:
  def __init__(self, x, y, r=0., Id=None):
    self.x = x
    self.y = y
    self.radius = r
    self.id = Id

  def __str__(self):
    return '({:.2f}, {:.2f})'.format(self.x, self.y)

  def __repr__(self):
    return self.__str__()



class Line:
  def params(self):
    if abs(self.dx) <= self.tol:  # eq for vertical-line
      return self.x0, None  # b==None -> vertical-line
    m = truediv(self.dy, self.dx)
    b = self.y0 - m * self.x0
    return m, b

  def __init__(self, e0, e1, r=0., tol=1e-3):
    self.e0 = e0
    self.e1 = e1
    self.x0 = e0.x
    self.x1 = e1.x
    self.dx = self.x1 - self.x0
    self.y0 = e0.y
    self.y1 = e1.y
    self.dy = self.y1 - self.y0
    self.x_mid = self.x0 + self.dx/2
    self.y_mid = self.y0 + self.dy/2
    self.tol = tol

  def cross(self, l1):
    # time-conscious check if self (line0) crosses line1
    # see if intersect @ same time
    # check 2x2 boundaries
    # self_left
    # self_right
    # Path1_left
    # Path1_right
    return False

  def __str__(self):
    return '|%s---%s|'%(self.e0, self.e1)

  def __repr__(self):
    return self.__str__()



class Path(Line):
  def __init__(self, e0, e1, r):
    pass

  def cross(self, Path1):
    # time-conscious check if self (Path0) crosses Path1
    # see if intersect @ same time
    # check 2x2 boundaries
    # self_left
    # self_right
    # Path1_left
    # Path1_right
    return False


# from matplotlib import patches, pyplot as plt
# COLOR_CYCLE = plt.rcParams['axes.prop_cycle'].by_key()['color']
# class Pltr:
#   def __init__(self, x_max=None, y_max=None):
#     self.fig, self.ax = plt.subplots(dpi=500, figsize=(x_max/10, y_max/10))
#     self.x_max = x_max
#     self.y_max = y_max
#     self.ax.set_xlim(0, x_max)
#     self.ax.set_ylim(0, y_max)
#     self.ax.set_aspect('equal', adjustable='box')
#     # self.ax.invert_yaxis()  # game has inverted y-axis
#     self.ax.grid('on', which='both')
#     self.ax.set_xticks(range(0, x_max, 1), minor=True)
#     self.ax.set_yticks(range(0, y_max, 1), minor=True)

#   def show(self):
#     plt.show()

#   def savefig(self, turn, fmt='pdf'):
#     plt.savefig('paths_%s.%s'%(turn, fmt), format=fmt)
#     plt.cla()  # clear-current axes

#   def plt_line(self, l, width=5, annotate=True):
#     xs = [l.x0, l.x1]
#     ys = [l.y0, l.y1]
#     kwargs = {
#       'linewidth': width,
#       'marker': 'o',
#       'markersize': width,
#     }
#     # opt: id -> color
#     if hasattr(l.e0, 'id') and l.e0.id:
#       kwargs['color'] = COLOR_CYCLE[l.e0.id%len(COLOR_CYCLE)]
#     # self.ax.plot(xs, ys, c=, 'o-', linewidth=width, markersize=width)
#     self.ax.plot(xs, ys, **kwargs)
#     if annotate:
#       self.ax.annotate(l.e0, size=width*2, xy=(l.x0, l.y0), textcoords='data')
#       self.ax.annotate(l.e1, size=width*2, xy=(l.x1, l.y1), textcoords='data')
#       self.ax.arrow(l.x0, l.y0, l.dx/2, l.dy/2, shape='full', linewidth=0, length_includes_head=True, head_width=.5, facecolor='black', edgecolor='black', zorder=9)

#   def plt_lines(self, Lines):
#     for l in Lines:
#       self.plt_line(l)

#   def plt_path():
#     pass

#   def plt_circle(self, x, y, r, c='gray'):
#     crcl = patches.Circle((x, y), r, color=c, fill=False)
#     self.ax.add_patch(crcl)

#   def plt_circles(self, Locs):
#     for p in Locs:
#       self.plt_circle(p.x, p.y, p.radius)


"""ARK - clone transient obj & enrich w/ custom fields?

  # class ArkShip:
  #   def clone(s):
  #     self.

  #   def __init__(self):
  #     self.target
  #     self.target_status


  # class ArkPlanet:
  #   def __init__(self):
  #     self.docked
  """


if __name__ == '__main__':
  test = 'plot'

  if test=='geo':
    p11 = Loc(1, 1)
    p59 = Loc(5, 9)
    p73 = Loc(7, 3)
    l0 = Line(p11, p73)
    path0 = Path(l0)
    print(p11)
    print(l0)
    print(path0)
    # path0 = Path(Loc(74, 30), Loc(80.94, 21.44))
    # path1 = Path(Loc(74, 33), Loc(81.95, 21.74))
    # path2 = Path(Loc(74, 36), Loc(73.11, 47.49))
    # assert path0.cross(path1)
    # assert path0.cross(path2)
  elif test=='plot':
    p11 = Loc(1, 1, Id=1)
    p59 = Loc(5, 9, Id=2)
    p73 = Loc(7, 3, Id=3)
    p_3_19 = Loc(3, 19, Id=4)
    p_17_3 = Loc(17, 3, Id=5)
    l0 = Line(p11, p73)
    l1 = Line(p73, p59)
    l2 = Line(p_3_19, p_17_3)
    lines = [l0, l1, l2]

    c1_1_1 = Loc(1, 1, 1)
    c2_5_3 = Loc(2, 5, 3)
    circles = [c1_1_1, c2_5_3]

    pltr = Pltr(20, 20)
    # print(vars(pltr))
    pltr.plt_lines(lines)
    pltr.plt_circles(circles)
    pltr.show()
    # pltr.savefig('test')


