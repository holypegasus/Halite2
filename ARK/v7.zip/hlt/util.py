import logging, math
from collections import Counter, OrderedDict, defaultdict
from functools import partial, wraps
from operator import truediv
from time import time


def timit(f):
  @wraps(f)
  def wrap(*args, **kwargs):
    t0 = time()
    result = f(*args, **kwargs)
    t1 = time()
    logging.warning('%s took: %.0f ms', f.__name__, (t1-t0)*1000)
    return result
  return wrap


def timit_name(text):
  if text:  print(text)
  return timit


def setup_logger(name, file_name=None, level=logging.INFO):
  log = logging.getLogger(name)
  log.setLevel(level)
  # fh = logging.FileHandler('%s.log'%(file_name), mode='w')
  # fh.setFormatter(
  #   logging.Formatter('%(asctime)s <%(module)s.%(funcName)s:%(lineno)d> %(message)s', '%Y%m%d %H:%M:%S'))
  # log.addHandler(fh)
  sh = logging.StreamHandler()
  sh.setFormatter(
    logging.Formatter('%(asctime)s <%(module)s.%(funcName)s:%(lineno)d> %(message)s', '%Y%m%d %H:%M:%S'))
  log.addHandler(sh)
  return log


def logitr(itr, header=''):
  if itr and header:  logging.debug('%s: [%s]', header, len(itr))
  if issubclass(type(itr), dict):
    for k, v in sorted(itr.items()):
      logging.debug('%s -> %s', k, v)
  else:
    for v in itr: logging.debug(v)



class Loc:
  def __init__(self, *args, r=0., iD=None, rounD=2):
    if len(args) == 1:
      e = args[0]
      assert hasattr(e, 'x')
      x = e.x
      assert hasattr(e, 'y')
      y = e.y
      if hasattr(e, 'r'):
        r = e.r
    elif len(args) == 2:
      x, y = args
    self.x = round(x, rounD)
    self.y = round(y, rounD)
    self.radius = round(r, rounD)
    self.id = iD
    self.round = rounD

  def __str__(self):
    return '({:.2f}, {:.2f})'.format(self.x, self.y)

  def __repr__(self):
    return self.__str__()



class Line:
  def params(self):
    if abs(self.dx) <= self.tol:  # eq for vertical-line
      return self.x0, None  # b==None -> vertical-line
    m = truediv(self.dy, self.dx)
    b = self.y0 - m * self.x0
    return m, b

  def __init__(self, e0, e1, r=0., tol=1e-3, rounD=2):
    self.e0 = e0
    self.e1 = e1
    self.x0 = e0.x
    self.x1 = e1.x
    self.dx = self.x1 - self.x0
    self.y0 = e0.y
    self.y1 = e1.y
    self.dy = self.y1 - self.y0
    self.x_mid = self.x0 + self.dx/2
    self.y_mid = self.y0 + self.dy/2
    self.r = r
    self.tol = tol
    self.round = rounD

  def gen_pts(self, n):  # generate n pts along line, including end-points e0, e1
    dx = self.dx / (n-1)
    dy = self.dy / (n-1)
    next_x, next_y = self.x0, self.y0
    for _ in range(n):
      yield Loc(round(next_x, self.round), round(next_y, self.round), r=self.r)
      next_x += dx
      next_y += dy

  def cross(self, l1):
    # time-conscious check if self (line0) crosses line1?
    # see if intersect @ same time
    # check 2x2 boundaries in case of radius?
    # self_left
    # self_right
    # Path1_left
    # Path1_right
    m0, b0 = self.params()
    m1, b1 = l1.params()
    # set y equal, check x in both x-ranges
    # m0*x+b0 = m1*x+b1 -> x = (b0-b1)/(m1-m0)
    intersect_x = (b0-b1)/(m1-m0)
    if (min(self.x0, self.x1) <= intersect_x <= max(self.x0, self.x1)
      and min(l1.x0, l1.x1) <= intersect_x <= max(l1.x0, l1.x1)):
      return True
    else:
      return False

  def __str__(self):
    return '|%s---%s|'%(self.e0, self.e1)

  def __repr__(self):
    return self.__str__()



if __name__ == '__main__':
  logging.basicConfig(level=logging.INFO, format='<%(module)s.%(funcName)s:%(lineno)d> %(message)s')

  test='timit'

  if test=='timit':
    @timit
    def timed(t=1e4):
      assert t<=1e8
      t=int(t)
      for _ in range(t):  _
      logging.info('Running timed() {:,} times...'.format(t))

    timed(1e7)
  elif test=='log':
    # setup_logger
    log = setup_logger(__name__, level=logging.INFO)
    log.info('something')
    # logitr
    d = {str(i): i for i in range(5)}
    logitr(d, 'test_header')