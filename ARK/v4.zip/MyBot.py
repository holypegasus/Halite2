"""
Welcome to your first Halite-II bot!

This bot's name is Settler. It's purpose is simple (don't expect it to win complex games :) ):
1. Initialize game
2. If a ship is not docked and there are unowned planets
2.a. Try to Dock in the planet if close enough
2.b If not, go towards the planet

Note: Please do not place print statements here as they are used to communicate with the Halite engine. If you need
to log anything use the logging module.
"""
# Let's start by importing the Halite Starter Kit so we can interface with the Halite engine
import logging
from collections import OrderedDict

import hlt
from hlt import Game, constants, entity, util
from hlt.entity import Planet, Ship
from hlt.util import setup_logger, logitr


BOT_NAME = 'v4_rough_angler'
log = setup_logger(__name__, BOT_NAME, logging.WARNING)


ANGULAR_STEP = 30


def dock_or_navigate(command_queue, ship, target,
  avoid_obstacles=True, ignore_ships=False):
  log.info('Navigating: %s', ship)
  log.info('...> %s', target)
  # If we can dock, let's (try to) dock. If two ships try to dock at once, neither will be able to.
  if isinstance(target, Planet) and ship.can_dock(target):
    # We add the command by appending it to the command_queue
    log.info('DOCK!')
    command_queue.append(ship.dock(target))
  else:
    # If we can't dock, we move towards the closest empty point near this planet (by using closest_point_to)
    # with constant speed. Don't worry about pathfinding for now, as the command will do it for you.
    # We run this navigate command each turn until we arrive to get the latest move.
    # Here we move at half our maximum speed to better control the ships
    # In order to execute faster we also choose to ignore ship collision calculations during navigation.
    # This will mean that you have a higher probability of crashing into ships, but it also means you will
    # make move decisions much quicker. As your skill progresses and your moves turn more optimal you may
    # wish to turn that option off.
    navigate_command = ship.navigate(
      target=ship.closest_point_to(target),
      game_map=game_map,
      speed=int(constants.MAX_SPEED),
      avoid_obstacles=avoid_obstacles,
      angular_step=ANGULAR_STEP,
      ignore_ships=ignore_ships,
    )
    # If the move is possible, add it to the command_queue (if there are too many obstacles on the way
    # or we are trapped (or we reached our destination!), navigate_command will return null;
    # don't fret though, we can run the command again the next turn)
    if navigate_command:
      log.info('THRUST %s', navigate_command)
      command_queue.append(navigate_command)
    else:
      log.warning('##### NO navigate_command - max_corrections exceeded! #####')


# GAME START
game = Game(BOT_NAME)
log.warning("Starting my %s bot!", BOT_NAME)
turn_n = 0
while True:
  log.warning('<<<<< TURN %s >>>>>', turn_n)
  turn_n += 1
  # TURN START
  # Update the map for the new turn and get the latest version
  game_map = game.update_map()
  MY_ID = game_map.my_id
  # Here we define the set of commands to be sent to the Halite engine at the end of the turn
  command_queue = []
  # get planetary stats
  all_planets = set(game_map.all_planets())
  free_planets = set(p for p in all_planets if not p.is_owned())
  my_planets = set(p for p in (all_planets-free_planets) if p.owner.id==MY_ID)
  open_planets = set(p for p in my_planets if not p.is_full())
  log.info('Planets: %s/%s free; %s/%s open',
    len(free_planets), len(all_planets), len(open_planets), len(my_planets))

  # For every ship that I control
  my_ships = game_map.get_me().all_ships()
  mobile_ships = [s for s in my_ships if s.docking_status==s.DockingStatus.UNDOCKED]
  log.info('My Ships: %s/%s UNDOCKED', len(mobile_ships), len(my_ships))


  for ship in mobile_ships:
    log.info('Commanding %s', ship)
    # if still planets open or my planet not fully utilized, seek nearest
    free0open_planets = free_planets | open_planets
    if free0open_planets:
      dist2planet = game_map.get_dist2ent(ent0=ship, typ=entity.Planet)
      for dist, planet in sorted(dist2planet.items()):
        if planet in free0open_planets:
          dock_or_navigate(command_queue, ship, planet)
          break
    else:  # battle -> seek nearest defenseless enemy ship
      dist2ship = game_map.get_dist2ent(ent0=ship, typ=entity.Ship)
      enemy_immobile_dist2ship = {dist: ship for dist, ship in sorted(dist2ship.items()) if ship.owner.id!=MY_ID and ship.docking_status!=Ship.DockingStatus.UNDOCKED}
      # enemy_dist2ship = sorted({dist: ship for dist, ship in sorted(dist2ship.items()) if ship.owner.id!=MY_ID}.items())
      targets = sorted(enemy_immobile_dist2ship.items())
      if targets:
        target = targets[0][1]
        dock_or_navigate(command_queue, ship, target, ignore_ships=True)

  # Send our set of commands to the Halite engine for this turn
  game.send_command_queue(command_queue)
  # TURN END
# GAME END
