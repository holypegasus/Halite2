import logging
from collections import Counter, OrderedDict, defaultdict


def setup_logger(name, output_name):
  log = logging.getLogger(name)
  log.setLevel(logging.INFO)
  fh = logging.FileHandler('%s.log'%(output_name), mode='w')
  fh.setFormatter(
    logging.Formatter('%(asctime)s <%(module)s.%(funcName)s:%(lineno)d> %(message)s', '%Y%m%d %H:%M:%S'))
  log.addHandler(fh)
  return log


def logitr(logger, itr, header=''):
  if header:  logger.info(header)
  if issubclass(type(itr), dict):
    for k, v in itr.items():
      logger.info('%s -> %s', k, v)
  else:
    for v in itr: logger.info(v)


if __name__ == '__main__':
  log = setup_logger(__name__, 'util')

  d = {str(i): i for i in xrange(5)}

  logitr(log, d, 'test_header')

