import logging
from collections import defaultdict, namedtuple

from . import collision, constants, entity
from .util import logitr, timit


class Map:
  """
  Map which houses the current game information/metadata.
  
  :ivar my_id: Current player id associated with the map
  :ivar width: Map width
  :ivar height: Map height
  """

  def __init__(self, my_id, width, height):
    """
    :param my_id: User's id (tag)
    :param width: Map width
    :param height: Map height
    """
    self.my_id = my_id
    self.width = width
    self.height = height
    self._players = {}
    self._planets = {}
    # custom
    # keeps over turns
    self.sid2goal = defaultdict()  # ship.id -> goal.(type, id)
    self.ship_memo_null_return = (None, None)
    self.goal2sids = defaultdict(set)  # goal.(type, id) -> set(ship.[ids])
    self.goal_memo_null_return = set()
    # updates beginning of each turn
    self.rec = None
    self.obsts = set()  # static-obsts
    # self.paths = set()  # dynamic-obsts: plotted ship-paths
  

  #######
  # inter-turn memos
  # goal.(type, id) -> set(ship.[ids])
  def get_goal_memo(self, goal):
    if not goal:
      return self.goal_memo_null_return
    goal_typ8id = (type(goal), goal.id)
    return self.goal2sids.get(goal_typ8id, self.goal_memo_null_return)

  def show_goal_memo(self, level=logging.DEBUG):
    filter_none = [(k, v) for k, v in self.goal2sids.items() if k]
    logitr(filter_none, 'goal2sids (not ordered)', level)

  # ship.id -> target.(type, id)
  def get_ship_memo(self, ship):
    if not ship:
      return self.ship_memo_null_return
    return self.sid2goal.get(ship.id, self.ship_memo_null_return)

  # delete ship's memo & remove from its goal's ships, if any
  def del_ship_memo(self, sid):
    goal_typ8id = self.sid2goal.pop(sid)
    self.goal2sids[goal_typ8id].discard(sid)
    logging.info('%s -x-> %s!', sid, goal_typ8id)

  def show_ship_memo(self, level=logging.DEBUG):
    logitr(self.sid2goal, 'sid2goal', level)

  # given new (ship, goal), update sid2goal & goal2sids
  def update_ship8goal_memos(self, ship, goal):
    assert isinstance(goal, entity.Ship) or isinstance(goal, entity.Planet)
    logging.info('%s -> %s', ship, goal)
    # check if to deregister prev goal
    # ship can only have 1 goal
    goal_typ8id = self.sid2goal.get(ship.id, self.ship_memo_null_return)
    self.goal2sids[goal_typ8id].discard(ship.id)  # won't complain like remove()
    # register curr goal
    # goal might have >= 1 ship
    goal_typ8id = (type(goal), goal.id)
    self.sid2goal[ship.id] = goal_typ8id
    self.goal2sids[goal_typ8id].add(ship.id)
    # logging.info('goal_memo(%s): %s', goal_typ8id, self.goal2sids[goal_typ8id])

  # beginning-of-turn status-check ships if still alive
  # TODO check goals too?
  def refresh_ship8goal_memos(self):
    my_live_ship_ids = set(s.id for s in self.rec.my_ships)
    prev_turn_sids = [sid for sid in self.sid2goal.keys()]
    for sid in prev_turn_sids:
      if sid not in my_live_ship_ids:
        self.del_ship_memo(sid)


  # intra-turn memos
  # calc turn-stats -> namedtuple record
  # @timit
  def recalc_stats_record(self):
    all_ships = set(self._all_ships())
    my_ships = set(self.get_me().all_ships())
    my_mobos = set(s for s in my_ships if s.docking_status==s.DockingStatus.UNDOCKED)
    my_imobos = my_ships - my_mobos
    logging.warning('My Ships: %s/%s MOBO!', len(my_mobos), len(my_ships))
    foe_ships = all_ships - my_ships
    foe_mobos = set(s for s in foe_ships if s.docking_status==s.DockingStatus.UNDOCKED)
    foe_imobos = foe_ships - foe_mobos
    # Global entity status
    # my_docking_planets = set(s.planet for s in my_imobo_ships)
    # foe_docking_planets = set(s.planet for s in foe_imobo_ships)
    # logitr(foe_docking_planets, 'foe_docking_planets')
    # Get planetary stats
    all_planets = set(self.all_planets())
    owned_planets = set(p for p in all_planets if p.is_owned())
    my_planets = set(p for p in owned_planets if p.owner.id==self.my_id)
    foe_planets = owned_planets - my_planets
    free_planets = all_planets - owned_planets
    open_planets = set(p for p in my_planets if not p.is_full())
    logging.debug('Planets: %s/%s free; %s/%s open',
      len(free_planets), len(all_planets), len(open_planets), len(my_planets))
    # output
    names = ['all_ships', 'my_ships', 'my_mobos', 'my_imobos', 'foe_ships', 'foe_mobos', 'foe_imobos', 'all_planets', 'owned_planets', 'my_planets', 'foe_planets', 'free_planets', 'open_planets']
    rec = namedtuple('rec', ' '.join(names))(
      all_ships, my_ships, my_mobos, my_imobos, foe_ships, foe_mobos, foe_imobos,
      all_planets, owned_planets, my_planets, foe_planets, free_planets, open_planets)

    self.rec = rec
    return rec

  # reset obsts
  # TODO "where puck will be"
  def reset_obsts(self):
    r = self.rec
    self.obsts = r.all_planets | r.my_ships | r.foe_ships
    logitr(self.obsts, 'game_map.obsts', logging.DEBUG)
    return self.obsts


  def add_obst(self, new_obst):
    # assert new_obst not in self.obsts
    self.obsts.add(new_obst)


  def turn_update_memos(self):
    self.recalc_stats_record()
    self.reset_obsts()
    # update inter-turn memos - check if ship alive
    self.refresh_ship8goal_memos()


  #######

  def get_me(self):
    """
    :return: The user's player
    :rtype: Player
    """
    return self._players.get(self.my_id)

  def get_player(self, player_id):
    """
    :param int player_id: The id of the desired player
    :return: The player associated with player_id
    :rtype: Player
    """
    return self._players.get(player_id)

  def all_players(self):
    """
    :return: List of all players
    :rtype: list[Player]
    """
    return list(self._players.values())

  def get_planet(self, planet_id):
    """
    :param int planet_id:
    :return: The planet associated with planet_id
    :rtype: entity.Planet
    """
    return self._planets.get(planet_id)

  def all_planets(self):
    """
    :return: List of all planets
    :rtype: list[entity.Planet]
    """
    return list(self._planets.values())

  def nearby_entities_by_distance(self, ent):
    """
    :param ent: The source entity to find distances from
    :return: Dict containing all entities with their designated distances
      dist -> [ents]
    :rtype: dict
    """
    foreign_entities = self._all_ships() + self.all_planets()
    result = {}
    for foreign_entity in foreign_entities:
      if ent == foreign_entity:
        continue
      result.setdefault(ent.calculate_distance_between(foreign_entity), []).append(foreign_entity)
    return result

  # custom entity -> dist TODO smartify
  def get_dist2ent(self, ent0, typ=None):
    if typ == entity.Planet:
      foreign_entities = self.all_planets()
    elif typ == entity.Ship:
      foreign_entities = self._all_ships()
    else:
      foreign_entities = self._all_ships() + self.all_planets()
    dist2ent = {ent0.calculate_distance_between(ent1): ent1 for ent1 in foreign_entities if ent0!=ent1}
    return dist2ent

  def _link(self):
    """
    Updates all the entities with the correct ship and planet objects

    :return:
    """
    for celestial_object in self.all_planets() + self._all_ships():
      celestial_object._link(self._players, self._planets)

  def _parse(self, map_string):
    """
    Parse the map description from the game.

    :param map_string: The string which the Halite engine outputs
    :return: nothing
    """
    tokens = map_string.split()

    self._players, tokens = Player._parse(tokens)
    self._planets, tokens = entity.Planet._parse(tokens)

    assert(len(tokens) == 0)  # There should be no remaining tokens at this point
    self._link()

  def _all_ships(self):
    """
    Helper function to extract all ships from all players

    :return: List of ships
    :rtype: List[Ship]
    """
    all_ships = []
    for player in self.all_players():
      all_ships.extend(player.all_ships())
    return all_ships

  def _intersects_entity(self, target):
    """
    Check if the specified entity (x, y, r) intersects any planets. Entity is assumed to not be a planet.

    :param entity.Entity target: The entity to check intersections with.
    :return: The colliding entity if so, else None.
    :rtype: entity.Entity
    """
    for celestial_object in self._all_ships() + self.all_planets():
      if celestial_object is target:
        continue
      d = celestial_object.calculate_distance_between(target)
      if d <= celestial_object.radius + target.radius + 0.1:
        return celestial_object
    return None

  def obstacles_between(self, ship, target, ignore=()):
    """
    Check whether there is a straight-line path to the given point, without planetary obstacles in between.

    :param entity.Ship ship: Source entity
    :param entity.Entity target: Target entity
    :param entity.Entity ignore: Which entity type to ignore
    :return: The list of obstacles between the ship and target
    :rtype: list[entity.Entity]
    """
    obstacles = []
    entities = ([] if issubclass(entity.Planet, ignore) else self.all_planets()) \
      + ([] if issubclass(entity.Ship, ignore) else self._all_ships())
    for foreign_entity in entities:
      if foreign_entity == ship or foreign_entity == target:
        continue
      if collision.intersect_segment_circle(ship, target, foreign_entity, fudge=ship.radius + 0.1):
        obstacles.append(foreign_entity)
    return obstacles

  # TMP check if within reach, ship -> target, ship is blocked by anything 
  def blocked(self, ship, reach, target):
    logging.debug('Checking blocked...')
    # TODO for ships get actual pos OR comp Path instead
    # obsts = set(ob for ob in self.obsts if ob.neq(ship) and ob.neq(target))
    obsts = self.obsts - set([ship, target])
    # TMP filter potential obstacles by dist within ship's reach
    obsts = [obst for obst in obsts if ship.dist(obst)-obst.radius <= reach or target.dist(obst)-obst.radius <= reach]
    logitr(obsts, 'obstacles after filter')
    return any(collision.intersect_segment_circle(ship, target, obst) for obst in obsts)

  # TODO along given path, nearest obstacle to intersect
  # NEXT -> sector-sweep-search
  def nearest_obst_along_path(self, start, end, reach=constants.MAX_SPEED):
    assert reach <= constants.MAX_SPEED
    obsts = self.obsts - set([ship, target])
    d, nearest_obst = min()    


class Player:
  """
  :ivar id: The player's unique id
  """
  def __init__(self, player_id, ships={}):
    """
    :param player_id: User's id
    :param ships: Ships user controls (optional)
    """
    self.id = player_id
    self._ships = ships

  def all_ships(self):
    """
    :return: A list of all ships which belong to the user
    :rtype: list[entity.Ship]
    """
    return list(self._ships.values())

  def get_ship(self, ship_id):
    """
    :param int ship_id: The ship id of the desired ship.
    :return: The ship designated by ship_id belonging to this user.
    :rtype: entity.Ship
    """
    return self._ships.get(ship_id)

  @staticmethod
  def _parse_single(tokens):
    """
    Parse one user given an input string from the Halite engine.

    :param list[str] tokens: The input string as a list of str from the Halite engine.
    :return: The parsed player id, player object, and remaining tokens
    :rtype: (int, Player, list[str])
    """
    player_id, *remainder = tokens
    player_id = int(player_id)
    ships, remainder = entity.Ship._parse(player_id, remainder)
    player = Player(player_id, ships)
    return player_id, player, remainder

  @staticmethod
  def _parse(tokens):
    """
    Parse an entire user input string from the Halite engine for all users.

    :param list[str] tokens: The input string as a list of str from the Halite engine.
    :return: The parsed players in the form of player dict, and remaining tokens
    :rtype: (dict, list[str])
    """
    num_players, *remainder = tokens
    num_players = int(num_players)
    players = {}

    for _ in range(num_players):
      player, players[player], remainder = Player._parse_single(remainder)

    return players, remainder

  def __str__(self):
    return "Player {} with ships {}".format(self.id, self.all_ships())

  def __repr__(self):
    return self.__str__()
