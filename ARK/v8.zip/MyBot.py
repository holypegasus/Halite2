"""
Welcome to your first Halite-II bot!

This bot's name is Settler. It's purpose is simple (don't expect it to win complex games :) ):
1. Initialize game
2. If a ship is not docked and there are unowned planets
2.a. Try to Dock in the planet if close enough
2.b If not, go towards the planet

Note: Please do not place print statements here as they are used to communicate with the Halite engine. If you need
to log anything use the logging module.
"""
# Let's start by importing the Halite Starter Kit so we can interface with the Halite engine
import logging
import numpy as np
from collections import Counter, OrderedDict, defaultdict, namedtuple
from itertools import chain
from time import time

import hlt
from hlt import Game, constants
from hlt.entity import Entity, Planet, Ship, Position
from hlt.util import setup_logger, logitr, timit, Loc, Line, Grid


BOT_NAME = 'v8_scan_perim_fix_thrust'
# Game params
LOG_LEVEL = logging.DEBUG
LOG_LEVEL = logging.INFO
LOG_LEVEL = logging.WARNING
LOG_LEVEL = logging.CRITICAL
LIMIT_TURNS = float('inf')
# LIMIT_TURNS = 10
PLOT_TURNS = set()
# PLOT_TURNS = set(chain(range(0, LIMIT_TURNS)))

# Logic params
ANGULAR_STEP = 10
MAX_CORRECTIONS = 10
PC = 2  # coordinate-precision
TIMEOUT_BREAKER = 1.800


def log(msg, level=logging.DEBUG):
  logger = {
    logging.DEBUG: logging.debug,
    logging.INFO: logging.info,
    logging.WARNING: logging.warning,
  }.get(level)
  logger(msg)


# find threats within origin's safety-perimeter
# return unclaimed nearest threat to ship
# TODO generalize to area_threat_vector
def scan_perimeter(ship, origin):
  # dist8nearest_foe_ship = min([(origin.dist(s), s) for s in r.foe_ships], key=lambda ds: ds[0])
  r = game_map.rec

  turns_to_safe = constants.DOCK_TURNS
  # all (dist, foe_ship) in perimeter
  # TODO generalize to all foe_ship w/ threat_vector into perimeter
  # ? foe_ships vs foe_mobos
  goal_dist_to8foes = []
  for foe in r.foe_ships:
    dist_to = origin.dist(foe)
    turns_from_foe = origin.dist(foe) / constants.MAX_SPEED
    if turns_from_foe <= turns_to_safe:
      goal_dist_to8foes.append((dist_to, foe))
  logitr(goal_dist_to8foes, 'goal_dist_to8foes', sort_key=lambda d8f: d8f[0])

  sorted_ship_dist_to8foe = sorted([(ship.dist(f), f) for (_, f) in goal_dist_to8foes], key=lambda d8f: d8f[0])
  logitr(sorted_ship_dist_to8foe, 'ship_dist_to8foe', 20)
  for ship_dist_to, foe in sorted_ship_dist_to8foe:
    goal_memo = game_map.get_goal_memo(foe)  # sids
    if not goal_memo or ship.id in goal_memo:
      logging.info('Perimeter_foe! %s @ %.1f from %s', foe, ship_dist_to, ship)
      return ship_dist_to, foe

  # # assess risk
  # dist_to, nearest_foe_ship = dist8nearest_foe_ship
  # # TODO turns_away <~ precomputed path-graph
  # # ? consider if escort/reinforcement coming
  # turns_away = dist_to / constants.MAX_SPEED
  # if turns_away <= turns_needed:
  #   logging.info('Perimeter_threat! %s @ %.1f turn-away', nearest_foe_ship, turns_away)
  #   return dist_to, nearest_foe_ship
  return None, None

# TODO
def guess_next_loc(foe_ship):
  # ship registry stores past moves -> project next
  # start simple - return None unless highly certain
  pass


# update memo when ship stays
def stay(ship):
  game_map.add_obst(ship)


# @timit
def get_act(ship, goal):
  assert isinstance(goal, Planet) or isinstance(goal, Ship)
  logging.info('%s --d:%s--> %s', ship, ship.dist(goal), goal)
  r = game_map.rec
  navigate_command = None
  if isinstance(goal, Planet) and ship.can_dock(goal):
    logging.info('DOCK! %s, %.2f away from %s', ship, ship.dist(goal)-goal.radius, goal)
    # game_map.update_ship8goal_memos(ship, goal)
    navigate_command = ship.dock(goal)
    stay(ship)
  else:
    # TODO make sure rounding min_dist correctly for various scenarios
    if isinstance(goal, Planet):
      min_dist = .5 # hug planet!  #constants.DOCK_RADIUS - .5
    elif isinstance(goal, Ship):
      MIN_MOVE_THRUST = 1
      desired_min_dist = constants.WEAPON_RADIUS  # TEST if further better
      dist_to_goal = ship.dist(goal)
      if dist_to_goal <= desired_min_dist:
        stay(ship)
        return
      else:
        # NB when just beyond, make sure THRUST at least 1
        # eg @5.28 away trying to keep 4 min_dist from a radius 0.5 ship
        # 0.78 thrust rounds to 0 !!!
        # want: 1 <= THRUST = dist_to_goal - (desired_min_dist + goal.radius)
        # thus: min_dist = dist_to_goal - goal.radius - 1 in edge case
        lower_bound_min_dist = max(0, dist_to_goal - goal.radius - MIN_MOVE_THRUST)
        min_dist = min(desired_min_dist, lower_bound_min_dist)
      # if ship.id==7:  logging.warning('MINDIST %s', min_dist)
    target = ship.perigee(goal, min_dist=min_dist)  # -> target-perigee
    logging.debug("goal's target-perigee: -> %s", target)
    navigate_command, eff_target = ship.navigate_smart(
      target=target,
      game_map=game_map,
      angular_step=ANGULAR_STEP,
      max_corrections=MAX_CORRECTIONS,
    )
    if navigate_command:  # move
      # game_map.update_ship8goal_memos(ship, goal)
      navi_path = Line(ship, eff_target, r=ship.radius, rounD=PC)
      # TMP sprinkle navigational dust into RESERVED_LOCS
      navi_dots = list(navi_path.gen_pts(int(constants.MAX_SPEED/ship.radius*2)))
      [game_map.obsts.add(navi_dot) for navi_dot in navi_dots]
      PATH_RECS.append(navi_path)
    else:  # no move
      game_map.obsts.add(ship)
      # check if anything dockable :D
      for p in (r.free_planets | r.open_planets):
        if ship.can_dock(p):
          logging.warning('Nothing to do but planet dockable next door...DOCK! %s -> %s', ship, p)
          # goal changed? need to update_ship8goal_memos
          game_map.update_ship8goal_memos(ship, p)
          navigate_command = ship.dock(p)
          stay(ship)

  return navigate_command


# to start just direct each ship to its optimal goal
# TODO spatial-search goal only within reachable 
@timit
def eval_goals():
  r = game_map.rec
  """
  TODO
    order ship intelligently (spatial - border first?)
    eval effective-dist (ED)
    update ED after each action?
  """
  goals = r.free_planets | r.open_planets | r.foe_imobos | r.foe_mobos
  logging.debug('%s ships; %s goals', len(r.my_mobos), len(goals))
  ship2dist8goal = dict()
  # ship2dist8goal = dict(list)
  for i, ship in enumerate(r.my_mobos):
    # TEST keep same goal if it has been foe_imobo
    # foe_imobo_id2ship = {s.id: s for s in r.foe_imobos}
    # goal_typ, goal_id = game_map.get_ship_memo(s)
    # if goal_typ==Ship and goal_id in foe_imobo_id2ship:
    #   prev_goal_foe_imobo = foe_imobo_id2ship[goal_id]
    #   logging.info('%s keeping same goal: %s', s, prev_goal_foe_imobo)
    #   ship2dist8goal[s] = s.dist(prev_goal_foe_imobo), prev_goal_foe_imobo
    # else:
      # ... section below

    # pick goal
    # TODO pick goal smarter
    for goal in goals:
      # check if already targeted
      # TODO nuant w/ area-threat-vector-analysis
      if isinstance(goal, Planet):
        committed_ships = game_map.get_goal_memo(goal)
        # logging.info('get_goal_memo(%s): %s', goal, committed_ships)
        open_docks = goal.num_docking_spots - len(committed_ships)
        if open_docks <= 0 and ship.id not in committed_ships:
          continue
      ### TODO eval target + effective dist
      dist = ship.dist(goal)
      if ship not in ship2dist8goal or dist < ship2dist8goal[ship][0]:
        ship2dist8goal[ship] = dist, goal
        # ship2dist8goal[s].append((d, g))  # carry list of possible goals
    # double-check goal after first-pass through all-goals
    dist, goal = ship2dist8goal[ship]  # best (dist, goal) for ship
    logging.debug('%s ..> %s', ship, goal)
    if isinstance(goal, Planet):
      # unmatched foe nearest ship
      ship_dist_to, perimeter_threat = scan_perimeter(ship, goal)
      # TMP redirect goal if original goal scan_perimeter reveals threat
      if perimeter_threat:
        logging.info('Redirecting %s => %s', ship, perimeter_threat)
        ship2dist8goal[ship] = (ship.dist(perimeter_threat), perimeter_threat)
        game_map.update_ship8goal_memos(ship, perimeter_threat)
      else:
        game_map.update_ship8goal_memos(ship, goal)
    else:  # goal is a foe_ship
      game_map.update_ship8goal_memos(ship, goal)



  sorted_dist8ship8goal = sorted(((d8g[0], s, d8g[1]) for s, d8g in ship2dist8goal.items()), key=lambda dsg: dsg[0])
  logitr(sorted_dist8ship8goal, 'sorted_dist8ship8goal', 10)
  return sorted_dist8ship8goal


@timit
def turn():
  # Update the map for the new turn and get the latest version
  game.update_map()
  # from curr_turn game_map recalc various records & update memos
  game_map.turn_update_memos()
  # TURN START
  command_queue = []
  # TODO iterate-merge eval_goal & get_act
  # eval a goal per ship & update ship & goal memos
  sorted_dist8ship8goal = eval_goals()
  # foreach goal/
  t0 = time()
  for i, (dist, ship, goal) in enumerate(sorted_dist8ship8goal):
    # return before timeout
    td = time() - t0
    logging.debug(td)
    if td >= TIMEOUT_BREAKER:
      break
    navigate_command = get_act(ship, goal)
    if navigate_command:
      command_queue.append(navigate_command)

  # OPT show memos end-of-turn
  game_map.show_ship_memo(level=20)
  game_map.show_goal_memo(level=20)
  # Send our set of commands to the Halite engine for this turn
  logitr([c.split()[1:] for c in command_queue], 'command_queue', level=20)
  game.send_command_queue(command_queue)
  # TURN END



# GAME START
game = Game(name=BOT_NAME, log_level=LOG_LEVEL)
gm = game_map = game.map
# TODO 60secs of preprocess window here!
# INTER-turn memos
# TODO target-registry -> write own memory-keeping Planet, Ship types 
# SID2TGT = dict()  # ship.id -> target.(type, (x, y))
# PID2SIDS = defaultdict(set)  # planet.id -> set(ship.ids)
# TODO adapt strategy by layout/density/dist etc.
# if len(game_map._players)==2:
#   BUILD_Q = 2
#   FIGHT_Q = 4
# else:  # 4-players
#   BUILD_Q = 4
#   FIGHT_Q = 4

# Main
while True:
  if game.curr_turn > LIMIT_TURNS:  break  # short-horizon tests
  # INTRA-turn memos -> should all go into game_map
  PATH_RECS = []
  turn()
  # opt plot
  if game.curr_turn in PLOT_TURNS and PATH_RECS:
    from hlt.plot import Pltr
    pltr = Pltr(game_map.width, game_map.height)

    r = game_map.rec
    pltr.plt_circles(r.free_planets, c='gray')
    pltr.plt_circles(r.foe_mobos, c='red')
    pltr.plt_circles(r.foe_imobos, c='purple')
    pltr.plt_circles(r.foe_planets, c='purple')
    pltr.plt_circles(r.my_mobos, c='blue')
    # TODO plot mobo but not moving ship (esp WEAPON_RADIUS)
    pltr.plt_circles(r.my_imobos, c='green')
    pltr.plt_circles(r.my_planets, c='green')
    pltr.plt_lines(PATH_RECS)

    # grid = Grid(game_map, precision=0)
    # grid.map_entities(game_map.all_planets())
    # pltr.plt_matrix(grid)

    # pltr.show()
    pltr.savefig(turn=game.curr_turn)
# GAME END
