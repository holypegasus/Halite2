from matplotlib import patches, pyplot as plt


WEAPON_RADIUS = 5.0
DOCK_RADIUS = 4.0


COLOR_CYCLE = plt.rcParams['axes.prop_cycle'].by_key()['color']
def pick_color(eid):
  return COLOR_CYCLE[eid%len(COLOR_CYCLE)]


class Pltr:
  def __init__(self, x_max=None, y_max=None):
    self.fig, self.ax = plt.subplots(dpi=500, figsize=(x_max/10, y_max/10))
    self.x_max = x_max
    self.y_max = y_max
    self.ax.set_xlim(0, x_max)
    self.ax.set_ylim(0, y_max)
    self.ax.set_aspect('equal', adjustable='box')
    self.ax.invert_yaxis()  # game has inverted y-axis
    self.ax.grid('on', which='both')
    self.ax.set_xticks(range(0, x_max, 1), minor=True)
    self.ax.set_yticks(range(0, y_max, 1), minor=True)

  def show(self):
    plt.show()

  def savefig(self, turn, fmt='pdf'):
    plt.savefig('paths_%s.%s'%(turn, fmt), format=fmt)
    plt.cla()  # clear-current axes

  def plt_line(self, l, width=5, annotate=True):
    xs = [l.x0, l.x1]
    ys = [l.y0, l.y1]
    kwargs = {
      'linewidth': width,
      'marker': 'o',
      'markersize': width,
    }
    # opt: id -> color
    if hasattr(l.e0, 'id') and l.e0.id!=None:
      kwargs['color'] = color = pick_color(l.e0.id)
      # plot WEAPON_RADIUS
      crcl = patches.Circle((l.x1, l.y1), WEAPON_RADIUS, color=color, fill=False)
      self.ax.add_patch(crcl)
      # plot DOCK_RADIUS
      crcl = patches.Circle((l.x1, l.y1), DOCK_RADIUS, color=color, fill=False)
      self.ax.add_patch(crcl)
    # self.ax.plot(xs, ys, c=, 'o-', linewidth=width, markersize=width)
    self.ax.plot(xs, ys, **kwargs)
    if annotate:
      self.ax.annotate(l.e0, size=width*2, xy=(l.x0, l.y0), textcoords='data')
      self.ax.annotate(l.e1, size=width*2, xy=(l.x1, l.y1), textcoords='data')
      self.ax.arrow(l.x0, l.y0, l.dx/2, l.dy/2, shape='full', linewidth=0, length_includes_head=True, head_width=.8, facecolor='black', edgecolor='black', zorder=9)

  # @timit
  def plt_lines(self, Lines):
    for l in Lines:
      self.plt_line(l)

  def plt_circle(self, ent, c=None, cid=None):
    x = ent.x
    y = ent.y
    r = ent.radius
    if c:
      color = c
    elif cid:
      color = pick_color(cid)
    elif hasattr(ent, 'id') and ent.id:
      color = pick_color(ent.id)
    else:
      color='gray'
    crcl = patches.Circle((x, y), r, color=color, fill=ent.owner)
    self.ax.add_patch(crcl)

  # @timit
  def plt_circles(self, ents, c=None, cid=None):
    for ent in ents:
      self.plt_circle(ent, c, cid)


  # @timit
  def plt_matrix(self, matrix):
    # easy but not very detailed
    # self.ax.matshow(matrix)

    # plot over current grid
    nz = np.nonzero(matrix)
    logging.warning(nz)
    xs, ys = nz[1], nz[0]
    for x, y in zip(xs, ys):
      self.plt_circle(x, y, 0.2, 'red')



if __name__ == '__main__':
  print(COLOR_CYCLE)