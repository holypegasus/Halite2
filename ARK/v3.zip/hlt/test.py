import util


if __name__ == '__main__':
  log = util.setup_logger(__name__)
  d = {i: i for i in xrange(5)}
  log.info(d)
  util.logitr(itr=d, header='test_header', logger=log)