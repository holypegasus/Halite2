from matplotlib import patches, pyplot as plt

from .util import *



COLOR_CYCLE = plt.rcParams['axes.prop_cycle'].by_key()['color']
class Pltr:
  def __init__(self, x_max=None, y_max=None):
    self.fig, self.ax = plt.subplots(dpi=500, figsize=(x_max/10, y_max/10))
    self.x_max = x_max
    self.y_max = y_max
    self.ax.set_xlim(0, x_max)
    self.ax.set_ylim(0, y_max)
    self.ax.set_aspect('equal', adjustable='box')
    # self.ax.invert_yaxis()  # game has inverted y-axis
    self.ax.grid('on', which='both')
    self.ax.set_xticks(range(0, x_max, 1), minor=True)
    self.ax.set_yticks(range(0, y_max, 1), minor=True)

  def show(self):
    plt.show()

  def savefig(self, turn, fmt='pdf'):
    plt.savefig('paths_%s.%s'%(turn, fmt), format=fmt)
    plt.cla()  # clear-current axes

  def plt_line(self, l, width=5, annotate=True):
    xs = [l.x0, l.x1]
    ys = [l.y0, l.y1]
    kwargs = {
      'linewidth': width,
      'marker': 'o',
      'markersize': width,
    }
    # opt: id -> color
    if hasattr(l.e0, 'id') and l.e0.id:
      kwargs['color'] = COLOR_CYCLE[l.e0.id%len(COLOR_CYCLE)]
    # self.ax.plot(xs, ys, c=, 'o-', linewidth=width, markersize=width)
    self.ax.plot(xs, ys, **kwargs)
    if annotate:
      self.ax.annotate(l.e0, size=width*2, xy=(l.x0, l.y0), textcoords='data')
      self.ax.annotate(l.e1, size=width*2, xy=(l.x1, l.y1), textcoords='data')
      self.ax.arrow(l.x0, l.y0, l.dx/2, l.dy/2, shape='full', linewidth=0, length_includes_head=True, head_width=.5, facecolor='black', edgecolor='black', zorder=9)

  @timit
  def plt_lines(self, lines):
    for l in lines:
      self.plt_line(l)

  def plt_path():
    pass

  def plt_circle(self, x, y, r, c='gray'):
    crcl = patches.Circle((x, y), r, color=c, fill=False)
    self.ax.add_patch(crcl)

  @timit
  def plt_circles(self, Locs):
    for p in Locs:
      self.plt_circle(p.x, p.y, p.radius)


"""ARK - clone transient obj & enrich w/ custom fields?

  # class ArkShip:
  #   def clone(s):
  #     self.

  #   def __init__(self):
  #     self.target
  #     self.target_status


  # class ArkPlanet:
  #   def __init__(self):
  #     self.docked
  """


